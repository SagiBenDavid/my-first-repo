import React from "react";
export default function Home() {
  return (
    <div className="p-4 text-center">
      <h1 className="text-3xl font-bold text-blue-700">ברוך הבא ל-StudyFlow</h1>
      <p className="mt-2">המערכת החכמה לניהול סיכומים ומשימות לסטודנטים.</p>
    </div>
  );
}
