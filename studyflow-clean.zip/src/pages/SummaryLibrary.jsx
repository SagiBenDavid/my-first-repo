import React from "react";
export default function SummaryLibrary() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold">ספריית סיכומים</h2>
      <p>כאן תוכל לראות ולחפש סיכומים לפי קורסים.</p>
    </div>
  );
}
