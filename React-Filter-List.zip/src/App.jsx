import React, { useState, useEffect } from 'react';

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [robots, setRobots] = useState([]);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((res) => res.json())
      .then((data) => {
        setRobots(data.map(user => ({
          id: user.id,
          name: user.name,
          country: user.address.city,
          job: user.company.bs
        })));
      });
  }, []);

  const filtered = robots.filter(robot =>
    robot.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    robot.country.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container">
      <h2>{filtered.length} items filtered</h2>
      <input
        type="text"
        placeholder="Search by name or country..."
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <div className="list">
        {filtered.map(robot => (
          <div key={robot.id} className="item">
            <img src={`https://robohash.org/${robot.id}?size=100x100`} />
            <div>
              <h3>{robot.name} from {robot.country}</h3>
              <p>{robot.job}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
